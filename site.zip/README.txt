website
=======

GAWDS Website

As per DJ Sir's instructions, I have 

1. Removed all inline style things. It is all purely classes.
2. Created a new css file in css folder that contains the code earlier in <style></style>.
3. Put some sample images to convey the intended presentation for the What we do phrase.

What is not yet done : 
1. Proper English Editing and selection of phrases.
2. Uploading proper images (will be embedded when available).
3. Color scheme have not been much worked upon since last modification.

Thankyou.
